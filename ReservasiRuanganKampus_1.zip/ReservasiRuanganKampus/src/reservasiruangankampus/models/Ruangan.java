package reservasiruangankampus.models;

public class Ruangan {
    private String idRuangan;
    private String namaRuangan;
    private int kapasitas;
    private boolean status;

    public Ruangan(String idRuangan, String namaRuangan, int kapasitas, boolean status) {
        this.idRuangan = idRuangan;
        this.namaRuangan = namaRuangan;
        this.kapasitas = kapasitas;
        this.status = status;
    }

    // Method untuk cek ketersediaan ruangan
    public boolean cekKetersediaan(String tanggal, String waktuMulai, String waktuSelesai) {
        // Logika untuk cek ketersediaan ruangan
        return true; // Ruangan tersedia
    }

    // Method untuk update status ruangan
    public void updateStatus(boolean status) {
        this.status = status;
    }

    String getIdRuangan() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    String getNamaRuangan() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
