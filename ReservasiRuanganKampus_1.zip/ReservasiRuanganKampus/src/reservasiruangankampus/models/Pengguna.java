package reservasiruangankampus.models;

import java.util.List;

public class Pengguna {
    private String idPengguna;
    private String nama;
    private String email;
    private String role;

    public Pengguna(String idPengguna, String nama, String email, String role) {
        this.idPengguna = idPengguna;
        this.nama = nama;
        this.email = email;
        this.role = role;
    }

    // Method untuk buat reservasi
    public Reservasi buatReservasi(String idRuangan, String tanggal, String waktuMulai, String waktuSelesai) {
        // Buat reservasi baru dan kembalikan objek reservasi
        String idReservasi = "RS" + System.currentTimeMillis(); // ID reservasi unik
        return new Reservasi(idReservasi, idRuangan, this.idPengguna, tanggal, waktuMulai, waktuSelesai, "Tertunda");
    }
}
