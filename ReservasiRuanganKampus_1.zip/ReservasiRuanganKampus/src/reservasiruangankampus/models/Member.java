package reservasiruangankampus.models;

import java.util.ArrayList;
import java.util.List;

public class Member extends Pengguna {
    private final List<Reservasi> reservasiList;

    public Member(String idPengguna, String nama, String email, String role) {
        super(idPengguna, nama, email, role);
        this.reservasiList = new ArrayList<>();
    }

    public List<Reservasi> lihatReservasi() {
        return reservasiList;
    }

    public void buatReservasi(Reservasi reservasi) {
        reservasiList.add(reservasi);
        System.out.println("Reservasi berhasil dibuat.");
    }

    public boolean batalkanReservasi(String idReservasi) {
        return reservasiList.removeIf(reservasi -> reservasi.getIdReservasi().equals(idReservasi));
    }
}
