package reservasiruangankampus.models;

import java.util.ArrayList;
import java.util.List;

public class Gedung {
    private String idGedung;
    private String namaGedung;
    private String lokasi;
    private List<Ruangan> ruanganList;

    public Gedung(String idGedung, String namaGedung, String lokasi) {
        this.idGedung = idGedung;
        this.namaGedung = namaGedung;
        this.lokasi = lokasi;
        this.ruanganList = new ArrayList<>();
    }

    public String getIdGedung() {
        return idGedung;
    }

    public String getNamaGedung() {
        return namaGedung;
    }

    public String getLokasi() {
        return lokasi;
    }

    public List<Ruangan> getRuanganList() {
        return ruanganList;
    }

    public void tambahRuangan(Ruangan ruangan) {
        ruanganList.add(ruangan);
    }
}
