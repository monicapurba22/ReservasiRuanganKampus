package reservasiruangankampus.models;

import java.util.List;

public class Admin extends Pengguna {
    public Admin(String idAdmin, String namaAdmin, String email, String role) {
        super(idAdmin, namaAdmin, email, role);
    }

    public void kelolaRuangan(Ruangan ruangan) {
        System.out.println("Mengelola ruangan: " + ruangan.getNamaRuangan());
    }

    public List<Reservasi> lihatReservasi() {
        // Hanya contoh: Admin tidak memiliki daftar reservasi sendiri
        return null;
    }

    public void buatReservasi(Reservasi reservasi) {
        throw new UnsupportedOperationException("Admin tidak membuat reservasi.");
    }

    public boolean batalkanReservasi(String idReservasi) {
        throw new UnsupportedOperationException("Admin tidak membatalkan reservasi.");
    }
}
