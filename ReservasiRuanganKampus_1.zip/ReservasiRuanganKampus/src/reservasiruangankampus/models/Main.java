package reservasiruangankampus.models;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Scanner untuk input pengguna
        Scanner scanner = new Scanner(System.in);

        // Membuat objek Pengguna dan Ruangan
        Pengguna pengguna = new Pengguna("P001", "Ryan", "ryan@example.com", "Member");
        Ruangan ruangan = new Ruangan("R001", "Ruang A", 30, true);

        // Menampilkan menu utama
        System.out.println("Menu Utama");
        System.out.print("Masukkan tanggal peminjaman (yyyy-MM-dd): ");
        String tanggal = scanner.nextLine();
        System.out.print("Masukkan waktu mulai (HH:mm): ");
        String waktuMulai = scanner.nextLine();
        System.out.print("Masukkan waktu selesai (HH:mm): ");
        String waktuSelesai = scanner.nextLine();

        // Validasi ketersediaan ruangan
        if (ruangan.cekKetersediaan(tanggal, waktuMulai, waktuSelesai)) {
            // Buat reservasi
            Reservasi reservasi = pengguna.buatReservasi(ruangan.getIdRuangan(), tanggal, waktuMulai, waktuSelesai);
            System.out.println("Reservasi berhasil dibuat!");
            System.out.println("ID Reservasi: " + reservasi.getIdReservasi());
            System.out.println("Ruangan: " + ruangan.getNamaRuangan());
            System.out.println("Tanggal: " + tanggal);
            System.out.println("Waktu: " + waktuMulai + " - " + waktuSelesai);
        } else {
            System.out.println("Ruangan tidak tersedia pada waktu yang dipilih.");
        }

        // Tutup scanner
        scanner.close();
    }
}

