/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package reservasiruangankampus.models;
public class Reservasi {
    private String idReservasi;
    private String idRuangan;
    private String idPengguna;
    private String tanggal;
    private String waktuMulai;
    private String waktuSelesai;
    private String status;

    // Constructor
    public Reservasi(String idReservasi, String idRuangan, String idPengguna, String tanggal, String waktuMulai, String waktuSelesai, String status) {
        this.idReservasi = idReservasi;
        this.idRuangan = idRuangan;
        this.idPengguna = idPengguna;
        this.tanggal = tanggal;
        this.waktuMulai = waktuMulai;
        this.waktuSelesai = waktuSelesai;
        this.status = status;
    }

    // Getter untuk idReservasi
    public String getIdReservasi() {
        return idReservasi;
    }

    // Getter lainnya
    public String getIdRuangan() {
        return idRuangan;
    }

    public String getIdPengguna() {
        return idPengguna;
    }

    public String getTanggal() {
        return tanggal;
    }

    public String getWaktuMulai() {
        return waktuMulai;
    }

    public String getWaktuSelesai() {
        return waktuSelesai;
    }

    public String getStatus() {
        return status;
    }

    // Method untuk validasi konflik reservasi
    public boolean validasiKonflikReservasi(String waktuMulai, String waktuSelesai) {
        // Logika validasi konflik
        return false; // Misalnya, tidak ada konflik
    }

    // Method untuk mengubah reservasi
    public boolean ubahReservasi(String tanggal, String waktuMulai, String waktuSelesai) {
        this.tanggal = tanggal;
        this.waktuMulai = waktuMulai;
        this.waktuSelesai = waktuSelesai;
        return true; // Reservasi berhasil diubah
    }
}
